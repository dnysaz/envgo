# envGo

Zero-dependency micro-runtime (Go, single binary) that lets plain HTML +
Vanilla JS pages use `.env` variables **without ever exposing the key to the
browser**. It serves your static site and proxies API calls, replacing
`{VAR_NAME}` placeholders with real values inside the Go process — invisible
to DevTools, the Network tab, and browser memory.

[![License: MIT](https://img.shields.io/badge/License-MIT-blue.svg)](LICENSE)
[![Latest release](https://img.shields.io/github/v/release/dnysaz/envgo)](https://github.com/dnysaz/envgo/releases/latest)
[![Go version](https://img.shields.io/github/go-mod/go-version/dnysaz/envgo)](go.mod)

**Free and open source under the MIT license.** No paid tier, no licence key, no
account, no telemetry. Download it, use it commercially, modify it, ship it —
see [License](#license).

Full documentation: **https://envgo.dev/**

## Why

- `.env` in a browser leaks secrets (readable via F12 / Network / memory).
- Traditional backends (Express, Django) add huge `node_modules` just to hide a key.
- envGo is a single binary (~2–12 MB). No Node, no host runtime, no dependencies.

## Features

- Static file server + secure proxy in a single binary.
- Hot-reload: edit `.env` and the running process picks it up (no restart).
- Dashboard at `/__envgo_dashboard` — recent requests + variable *names*, never values.
- SSE/streaming passthrough (e.g. OpenAI `stream: true`).
- **Public gateway mode** (`--config`): fixed routes at `/api/<name>` with per-route allowlist, rate limiting, optional bearer auth, and response scrubbing.
- **TLS support** (`--tls`): auto-generated self-signed certificate for HTTPS.
- **PHP support**: execute `.php` files server-side with `.env` vars injected (php-cgi preferred for `header()` support).
- **Typo detection**: red banner if HTML `id` doesn't match `.env` key.
- Cross-platform: macOS, Linux, Windows.

---

## Install

### Prebuilt binaries

Download the archive for your platform from the
[latest release](https://github.com/dnysaz/envgo/releases/latest). Every release
includes a `SHA256SUMS` file you can use to verify the download.

| Platform | File |
|----------|------|
| macOS, Apple Silicon | `envGo-macOS-AppleSilicon.zip` |
| macOS, Intel | `envGo-macOS-Intel.zip` |
| Linux, amd64 | `envgo-linux-amd64` |
| Linux, arm64 | `envgo-linux-arm64` |
| Windows, amd64 | `envgo-windows-amd64.exe` |
| Windows, arm64 | `envgo-windows-arm64.exe` |

The Windows and Linux files are static, uncompressed Go executables. The
Windows `.exe` is the runtime, not an installer: running it directly starts
envGo and a console window is expected. The release target keeps the existing
macOS artifacts untouched and updates only the Windows/Linux files and
`dist/SHA256SUMS`.

The steps below assume you already have the files from a release archive or
have run `make release`. For platform-specific instructions, see the
[documentation](https://envgo.dev/download/).

### macOS

```bash
# Option 1: Manual
cp dist/envgo-darwin-arm64 ~/.local/bin/envgo   # Apple Silicon
cp dist/envgo-darwin-amd64 ~/.local/bin/envgo   # Intel

# Option 2: Double-click Install_envGo.command from the zip
```

### Linux (VPS / Server)

```bash
# AMD64 (most servers)
sudo cp dist/envgo-linux-amd64 /usr/local/bin/envgo
sudo chmod +x /usr/local/bin/envgo

# ARM64 (Raspberry Pi, Graviton, etc.)
sudo cp dist/envgo-linux-arm64 /usr/local/bin/envgo
sudo chmod +x /usr/local/bin/envgo
```

### Windows

The `.exe` is a console application, so a Command Prompt window appearing while
it runs is normal — do **not** run it by double-clicking, because that starts the
server and the window closes the instant the process exits. Open a terminal and
run `envgo run dev` instead.

#### Option 1 — PowerShell installer (recommended)

The installer detects AMD64/ARM64, verifies the SHA-256 entry in
`dist/SHA256SUMS`, installs to `%LOCALAPPDATA%\Programs\envGo` without admin
rights, and adds that directory to your user `PATH`.

```powershell
# If you get "cannot be loaded because running scripts is disabled":
#   powershell -NoProfile -ExecutionPolicy Bypass -File .\Install_envGo.ps1
powershell -NoProfile -ExecutionPolicy Bypass -File .\Install_envGo.ps1 -Architecture amd64
```

> The `-ExecutionPolicy Bypass` flag is needed because Windows ships with the
> `Restricted` policy, which blocks all scripts. It only applies to that single
> run — your system policy is not changed. A standalone copy of
> `Install_envGo.ps1` can be placed beside the Windows binary and checksum file.
> SmartScreen may warn on first run because the binary is not code-signed —
> choose **More info → Run anyway**. Always verify the installer and binary
> against `SHA256SUMS` before running them.

#### Option 2 — Manual install

```powershell
# 1. Place the binary (pick the one matching your CPU — most PCs use amd64):
#    dist\envgo-windows-amd64.exe   ->   AMD64 (Intel/AMD)
#    dist\envgo-windows-arm64.exe   ->   ARM64 (Surface Pro X, etc.)
mkdir C:\envgo
copy $env:USERPROFILE\Downloads\envgo-windows-amd64.exe C:\envgo\envgo.exe
```

Then add `C:\envgo` to your `PATH`. Use **either** method below.

**Method A — PowerShell (no admin rights):**

```powershell
# Run once in a new PowerShell window:
[Environment]::SetEnvironmentVariable(
  'Path',
  [Environment]::GetEnvironmentVariable('Path', 'User') + ';C:\envgo',
  'User'
)
```

**Method B — Windows GUI (visual):**

1. Press **Win + R**, type `sysdm.cpl`, press **Enter**.
2. **Advanced** tab → **Environment Variables…**.
3. Under **User variables** select **Path** → **Edit…**.
4. **New** → type `C:\envgo` → **OK** to close every dialog.
5. Open a **new** PowerShell window and run `envgo -v`.

> PATH changes only apply to terminals opened **after** the edit. Reopen the
> terminal if `envgo` is not recognized.

```text
envgo -v    # print version
envgo -h    # show help
```

### Verify

Confirm the download is intact before trusting it. All three installers
(`Install_envGo.command`, `scripts/install.sh`, `scripts/install.ps1`) look for
`SHA256SUMS` next to the binary and abort on a mismatch — including after the
binary's own `-h` startup check, in case the file changed mid-install. The macOS
zips ship `SHA256SUMS` inside, so the double-click installer verifies too. If the
manifest is missing, the installer says so instead of pretending it checked.

To verify by hand:

```bash
# Linux
sha256sum -c SHA256SUMS
# macOS
shasum -a 256 -c SHA256SUMS
# Windows (PowerShell)
Get-FileHash -Algorithm SHA256 .\envgo-windows-amd64.exe
```

Then confirm the binary runs:

```bash
envgo -v    # print version
envgo -h    # show help
```

### Update

Update in place — works on macOS, Linux and Windows:

```bash
envgo run update
# > Update envgo to latest version? Y/n
```

It queries the GitHub releases API, downloads the binary for your platform over
HTTPS, verifies it against the release `SHA256SUMS` plus a startup self-check,
then replaces the running binary and prints `Congrats to new version of envgo!`.
Run it outside of a long-lived server (it never starts one). On macOS/Linux the
rename is atomic and a running server picks up the new binary on its next
restart; on Windows the replacement is scheduled after the current process exits.
Honors `HTTP_PROXY`/`HTTPS_PROXY` for downloads. For offline hosts, download the
binary from the [releases page](https://github.com/dnysaz/envgo/releases) and
copy it over the old install path, verifying with `sha256sum -c SHA256SUMS`
(Linux) or `shasum -a 256 -c SHA256SUMS` (macOS).

---

## Quick Start

### 1. Create a project

```bash
mkdir myapp && cd myapp
envgo init
```

This creates:
- `.env` — your secrets (MY_SECRET, HOST, PORT)
- `.env.example` — template (safe to commit)
- `index.html` — minimal starter page
- `.gitignore` — ignores `.env`
- `README.md` — project docs

### 2. Edit `.env`

```bash
# Add your real secrets
MY_SECRET=your-real-secret-here
HOST=127.0.0.1
PORT=8080
# MODE_PUBLIC=false  # true/public = public gateway (needs envgo.routes.json)
# CONFIG=envgo.routes.json  # explicit routes file (overrides MODE_PUBLIC)
```

### 3. Run

```bash
envgo run dev
# → http://127.0.0.1:8080/
# Browser opens automatically
```

### 4. Use in HTML

```html
<!DOCTYPE html>
<html>
<head><title>My App</title></head>
<body>
<h1>Hello from envGo!</h1>
<div id="MY_SECRET"></div>
<script src="/__env.js"></script>
</body>
</html>
```

The `<div id="MY_SECRET">` will show "✓ MY_SECRET — Success" if the key
exists in `.env`. The actual value **never** reaches the browser.

---

## Local Mode (Development)

Local mode uses `/proxy` endpoint with a session token. Best for development.

```bash
# Basic
envgo run dev

# With specific port and allowlist
envgo --port 3000 --dir . --env .env --allow api.openai.com,httpbin.org

# Open browser automatically
envgo run dev -b
```

### How it works

1. Browser fetches token: `GET /__envgo_token`
2. Browser sends request to `/proxy` with token:
```js
const token = await fetch("/__envgo_token").then(r => r.text());
const res = await fetch("/proxy", {
  method: "POST",
  headers: {
    "Content-Type": "application/json",
    "X-EnvGo-Token": token,
  },
  body: JSON.stringify({
    target_url: "https://api.openai.com/v1/chat/completions",
    method: "POST",
    headers: { "Authorization": "Bearer {OPENAI_API_KEY}" },
    body: { model: "gpt-4o", messages: [{ role: "user", content: "Hi" }] }
  })
});
```

3. Go server replaces `{OPENAI_API_KEY}` with real value, forwards to API.
4. Response returned to browser. **Secret never exposed.**

### Security

- Session token required for every `/proxy` call
- Host header validation (anti DNS-rebinding)
- Origin validation (anti cross-tab attacks)
- `--allow` restricts which hosts can be proxied

---

## Public Mode (Production Gateway)

Public mode uses fixed routes at `/api/<name>` — no token handshake needed.

### 1. Create route config

Create `envgo.routes.json`:

```json
{
  "trust_proxy": true,
  "default_rate_limit": "30/min",
  "scrub_response": true,
  "routes": [
    {
      "name": "chat",
      "method": "POST",
      "target": "https://api.openai.com/v1/chat/completions",
      "vars": ["OPENAI_API_KEY"],
      "inject": {
        "headers": { "Authorization": "Bearer {OPENAI_API_KEY}" }
      },
      "rate_limit": "20/min"
    },
    {
      "name": "gemini",
      "method": "POST",
      "target": "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent",
      "vars": ["GEMINI_API_KEY"],
      "inject": {
        "query": { "key": "{GEMINI_API_KEY}" }
      },
      "rate_limit": "20/min"
    }
  ]
}
```

### 2. Run

```bash
# via flag (classic)
envgo --config envgo.routes.json --env .env --dir . --host 127.0.0.1 --port 8080

# or via .env alone (new): set MODE_PUBLIC=true in .env then
envgo run dev
# same as above, reads MODE_PUBLIC + CONFIG from .env
```

### 3. Frontend calls

```js
// No token needed
const res = await fetch("/api/chat", {
  method: "POST",
  headers: { "Content-Type": "application/json" },
  body: JSON.stringify({
    model: "gpt-4o",
    messages: [{ role: "user", content: "Hello!" }]
  })
});
```

### Config reference

| Field | Type | Description |
|-------|------|-------------|
| `trust_proxy` | bool | Trust `X-Forwarded-For` when behind reverse proxy |
| `default_rate_limit` | string | e.g. `30/min`, `5/s`, `100/hour` |
| `scrub_response` | bool | Replace secrets in response with `[REDACTED]` |
| `routes[].name` | string | URL segment at `/api/<name>` |
| `routes[].target` | string | Upstream URL (HTTPS only) |
| `routes[].method` | string | Allowed method (default: POST) |
| `routes[].vars` | string[] | Env vars allowed for this route |
| `routes[].inject.query` | map | Query params added to upstream |
| `routes[].inject.headers` | map | Headers added to upstream |
| `routes[].inject.body` | map | JSON fields merged into body |
| `routes[].rate_limit` | string | Per-route limit (overrides default) |
| `routes[].auth` | object | `{ "type": "bearer", "secret": "{ENV_VAR}" }` |

---

## Deploy to VPS (Production)

### Option A: envgo directly (Simple)

**Step 1: Upload to VPS**

```bash
# From your local machine
scp dist/envgo-linux-amd64 user@your-vps:/tmp/envgo
scp -r . user@your-vps:/var/www/myapp

# SSH to VPS
ssh user@your-vps
```

**Step 2: Install on VPS**

```bash
sudo cp /tmp/envgo /usr/local/bin/envgo
sudo chmod +x /usr/local/bin/envgo
```

**Step 3: Configure**

```bash
cd /var/www/myapp

# Edit .env with real secrets
nano .env
```

**Step 4: Run with TLS**

```bash
# Option 1: Direct HTTPS (self-signed cert)
envgo --tls --dir . --env .env --allow api.openai.com

# Option 2: Public mode with routes
envgo --tls --config envgo.routes.json --env .env --dir .
```

**Step 5: Run as service (optional)**

Create `/etc/systemd/system/envgo.service`:

```ini
[Unit]
Description=envGo Server
After=network.target

[Service]
Type=simple
User=www-data
WorkingDirectory=/var/www/myapp
ExecStart=/usr/local/bin/envgo --dir /var/www/myapp --env /var/www/myapp/.env --allow api.openai.com --port 8080
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
```

```bash
sudo systemctl daemon-reload
sudo systemctl enable envgo
sudo systemctl start envgo
```

---

### Option B: Reverse Proxy (Recommended for Production)

envGo runs on localhost, Caddy/nginx handles TLS.

**Step 1: Run envGo on localhost**

```bash
cd /var/www/myapp

# Local mode
envgo --dir . --env .env --allow api.openai.com --port 8080

# Public mode
envgo --config envgo.routes.json --env .env --dir . --port 8080
```

**Step 2: Install Caddy**

```bash
# Debian/Ubuntu
sudo apt install -y caddy

# CentOS/RHEL
sudo yum install -y caddy
```

**Step 3: Configure Caddy**

Edit `/etc/caddy/Caddyfile`:

```
yourdomain.com {
    reverse_proxy 127.0.0.1:8080
}
```

**Step 4: Start Caddy**

```bash
sudo systemctl enable caddy
sudo systemctl start caddy
```

Caddy auto-generates TLS certificate via Let's Encrypt.

**Step 5: Update envgo routes config**

```json
{
  "trust_proxy": true,
  ...
}
```

---

### Option C: Docker

**Step 1: Create Dockerfile**

```bash
envgo deploy -o ./deploy
```

**Step 2: Build and run**

```bash
cd deploy
docker build -t envgo .
docker run -d -p 8080:8080 --name envgo envgo
```

---

## TLS (HTTPS)

### Self-signed (dev/testing)

```bash
envgo --tls --dir . --env .env
# → https://127.0.0.1:8080/
```

Auto-generates self-signed certificate. Browser will show warning — click
"Advanced" → "Proceed" to continue.

### Production (recommended)

Use Caddy/nginx as reverse proxy. They handle TLS termination with
Let's Encrypt certificates automatically.

```bash
# envGo runs plain HTTP on localhost
envgo --dir . --env .env --port 8080

# Caddy handles HTTPS
caddy reverse-proxy --from yourdomain.com --to localhost:8080
```

---

## PHP Support

envGo can execute PHP files server-side with `.env` vars injected.

### Example

`index.php`:
```php
<?php
$secret = getenv("MY_SECRET");
if (!$secret) {
    echo "<h1>Error: MY_SECRET not configured</h1>";
} else {
    echo "<h1>Secret validated (value hidden)</h1>";
}
?>
```

### Security features

- **Typo detection**: If PHP code uses `getenv("WRONG_KEY")`, red banner appears
- **Security warning**: If PHP code does `echo getenv("KEY")`, red banner warns about secret exposure
- **Timeout**: PHP scripts limited to 30 seconds execution time
- **CGI mode**: Prefers `php-cgi` binary for proper `header()` and HTTP status support; falls back to CLI mode
- **POST body passthrough**: `$_POST` and `php://input` work correctly for POST/PUT/PATCH requests
- **Standard CGI variables**: `SCRIPT_FILENAME`, `REQUEST_METHOD`, `CONTENT_TYPE`, `CONTENT_LENGTH`, etc.
- **Safe pattern**: `$secret = getenv("KEY"); echo "...hidden..."` — no warning
- **Unsafe pattern**: `echo getenv("KEY")` — triggers security banner

---

## Environment Hot Reload

Edit `.env` while envGo is running — changes picked up within ~1.5 seconds.

```bash
# Terminal 1
envgo run dev

# Terminal 2
echo "NEW_SECRET=new-value" >> .env
# → [envGo] hot-reloaded 5 variables from .env
```

---

## Browser Hot Reload

While running in dev mode (`envgo run dev`), envGo watches `.html`, `.css`,
`.js`, and `.php` files under your web root. Saving one of them pushes a
`reload` event over SSE to every open browser tab, which then does
`location.reload()` — no manual refresh needed. No external dependencies,
browser extensions, or WebSocket server required.

- Triggered by file **create / modify / delete** (not content-only moves).
- `.css`/`.js` changes push `reload` (soft navigation reload); all other
  watched extensions push `reload`.
- Dev responses carry `Cache-Control: no-store` so browsers always refetch.
- Run `envgo cache clear` to broadcast a hard-reload to all tabs and tell
  browsers to drop cached assets (handy after an edit the watcher missed).

```bash
envgo run dev
# → browser auto-refreshes on every save to *.html / *.css / *.js / *.php
```

---

## Cache

In dev mode envGo serves assets with `Cache-Control: no-store`. To force every
connected browser to hard-reload and re-fetch fresh assets, run:

```bash
envgo cache clear
# → Cache cleared — browsers will hard-reload with fresh resources.
```

This POSTs to the running dev server's `/__envgo/admin/clear-cache` endpoint,
which broadcasts a `hardreload` event to all subscribed tabs. If no dev server
is running, use `envgo run update` to restart on the new binary, or run the
command from within a dev session.

---

## Phone / LAN Access (QR Code)

By default envGo binds `127.0.0.1`, so nothing on your network can reach it.
To open the same dev server on your phone, add `--qr`:

```bash
envgo run dev --qr
```

`--qr` does everything needed for LAN sharing in one flag:

1. Binds **all interfaces** (`0.0.0.0`) instead of loopback, so other devices
   can connect. A `--host` you set explicitly always wins.
2. Prints **both** URLs, so you can see at a glance which is which.
3. Prints a **QR code** of the LAN URL — scan it with your phone's camera and
   the page opens.

```
[envGo] envGo running -> http://127.0.0.1:8080/
[envGo] envGo network -> http://192.168.1.20:8080   (same network only)

██████████████  ▄▄▄▄▄  ██████████████
...
Scan with a phone on the same network to open: http://192.168.1.20:8080
```

**Only the host part changes — the port always comes from `.env` or `--port`.**
`PORT=3000` in `.env` gives you `http://127.0.0.1:3000` and
`http://192.168.x.x:3000`. That is deliberate: the QR must encode a LAN address
or a phone scanning it would try to reach its own loopback interface, which
resolves to the phone and fails. The local URL is still printed so you can keep
using it on the machine you are sitting at.

Notes:

- The QR always encodes `192.168.x.x`-style output from the LAN interface that is
  up and non-loopback. Link-local (`169.254.x.x`), multicast, and IPv6-only
  interfaces are skipped, since phones cannot reach them.
- If no LAN address exists, envGo says so instead of printing a QR that cannot
  work, and keeps serving on loopback.
- macOS may ask for permission to accept incoming connections the first time.
  If the phone cannot connect, allow `envgo` in **System Settings → Network →
  Firewall → Options**, and check the router is not isolating clients
  (guest networks often do).
- With `--tls` the self-signed certificate includes the LAN address, so the
  hostname matches, but the phone will still warn that the issuer is unknown.
- `--qr-format png` writes `qrcode_<ip>_<port>.png` instead of drawing in the
  terminal — useful when the terminal mangles the block characters.

Plain LAN sharing without a QR (for example to type the URL on a device by
hand) needs no flag at all:

```bash
envgo run dev --host 0.0.0.0
# → envGo running -> http://127.0.0.1:8080/
# → envGo network -> http://192.168.1.20:8080   (same network only)
```

---

## Dashboard

Open `http://127.0.0.1:8080/__envgo_dashboard` to see:

- Loaded variable **names** (never values)
- Last 200 requests (method, host, status, duration, variables used)
- Errors

Enable with `--dashboard` flag.

---

## Commands Reference

| Command | Description |
|---------|-------------|
| `envgo` | Show help (a bare `envgo` never starts a server) |
| `envgo run dev` | Start dev server, read HOST/PORT from .env, auto-open browser |
| `envgo run dev --qr` | Same, but share on your local network and print a QR code |
| `envgo run update` | Check for and install the latest envgo release |
| `envgo cache clear` | Broadcast a hard-reload to all dev-server browser tabs |
| `envgo init` | Create new project template in current directory |
| `envgo init -name myapp` | Create project in subdirectory `myapp/` |
| `envgo deploy -o ./deploy` | Generate Caddyfile, nginx.conf, Dockerfile |
| `envgo -v` | Print version |
| `envgo -h` | Show help |

### Flags

| Flag | Short | Description |
|------|-------|-------------|
| `--port` | `-p` | Port to listen on (default: 8080) |
| `--host` | | Interface to bind (default: 127.0.0.1) |
| `--dir` | `-d` | Web root directory (default: .) |
| `--env` | `-e` | Path to .env file (default: .env) |
| `--allow` | `-a` | Comma-separated outbound host allowlist |
| `--config` | `-c` | Path to routes JSON (enables public mode) |
| `--dashboard` | `-D` | Enable metadata dashboard |
| `--tls` | | Enable HTTPS with auto-generated cert |
| `--browser` | `-b` | Open browser automatically |
| `--qr` | | Bind all interfaces and print a QR code of the LAN URL |
| `--qr-format` | | `ansi` (terminal, default) or `png` (write a file) |
| `--debug` | | Verbose logging |
| `--version` | `-v` | Print version |
| `--help` | `-h` | Show help |

The module is named `envgo` and imports are `envgo/internal/...`. There are no
third-party dependencies, so there is no `go.sum`.

### `.env` overrides (no flag needed)

`envgo run` reads `HOST`/`PORT` from `.env`. Public mode can also be set from `.env` without flags:

```env
MODE_PUBLIC=true          # or false, 1/0, yes/no, public/local
# aliases: MODE, PUBLIC_MODE, ENVGO_MODE
CONFIG=envgo.routes.json  # or ENVGO_CONFIG, ROUTES — explicit path (wins over MODE_PUBLIC)
```
Flag `--config` always wins over `.env`. Example: `MODE_PUBLIC=true envgo run dev` starts public mode via `.env` alone.

---

## Security Checklist

Before going to production:

- [ ] `.env` is in `.gitignore` (never commit secrets)
- [ ] Using `--allow` to restrict proxy targets
- [ ] Running behind Caddy/nginx for TLS (not `--tls` direct)
- [ ] `trust_proxy: true` in routes config when behind reverse proxy
- [ ] envGo bound to `127.0.0.1` only (not `0.0.0.0`)
- [ ] Dashboard disabled in public mode (no `--dashboard`)
- [ ] `.env.example` has placeholder values only

---

## Repository Layout

```
internal/envconfig     .env parser
internal/envstore      hot-reloading store
internal/gateway       public-mode gateway
internal/token         per-session token
internal/server        static + guards + PHP
internal/proxy         injection + outbound engine
internal/ratelimit     fixed-window rate limiter
internal/history       in-memory request log
internal/logger        redacting logger
internal/hotreload     SSE broadcaster for browser live reload
internal/lan           local-network IPv4 discovery for --qr
internal/qr            QR encoder (Model 2) + PNG writer, written from scratch
scripts/               install.sh, install.ps1
dist/                  verified Windows/Linux output plus preserved macOS artifacts
```

## Threat Model

| Threat | Mitigation |
|--------|------------|
| Inspect Element / F12 | Secrets never enter browser; JS holds only placeholders |
| Network tab sniffing | Browser talks to localhost; key injected server-side |
| Cross-tab / XSS | `--allow` + session token + Host/Origin checks |
| SSRF | Proxy denied when `--allow` is empty |
| Abuse of fixed routes | Per-route `vars` allow-set + `rate_limit` + optional auth |
| Upstream secret leak | `scrub_response` redacts secrets from API responses |
| LAN access | Bound to `127.0.0.1` only. `--qr` and `--host 0.0.0.0` are the only ways to widen it, and neither is used by default |
| TLS downgrade | MinVersion TLS 1.2 when using `--tls` |
| PHP code execution | 30s timeout, typo detection, security warning |

---

## Contributing and feedback

Feedback of every size is welcome — a confusing error message is as useful to
hear about as a bug. See [CONTRIBUTING.md](CONTRIBUTING.md) for the full guide.

| What you have | Where to put it |
|---------------|-----------------|
| A bug or crash | [Open an issue](https://github.com/dnysaz/envgo/issues/new/choose) |
| An idea or question | [Start a discussion](https://github.com/dnysaz/envgo/discussions) |
| A security concern | Follow [SECURITY.md](SECURITY.md) — privately, not in a public issue |
| A docs problem | [dnysaz/envgo-site](https://github.com/dnysaz/envgo-site/issues) |

Before contributing code, note the two constraints that matter most: **no
third-party dependencies** (the standard library is the whole toolkit) and
**secrets must never reach the client**.

```bash
make build      # build ./envgo
make test       # run the test suite
make vet        # run go vet
make version    # print the single source of truth for the version
make release    # rebuild verified Windows/Linux binaries in dist/ (run on any OS)
make dist-macos # build both macOS binaries, repack the zips, refresh SHA256SUMS (macOS host only)
```

## License

MIT — see [LICENSE](LICENSE).

Copyright (c) 2026 Ketut Dana

You may use, copy, modify, merge, publish, distribute, sublicense, and sell
copies of this software, including for commercial and closed-source projects.
The only requirement is that the copyright notice and licence text are included.
There is no fee, no registration, and no restriction on the number of users,
servers, or deployments.

The software is provided "as is", without warranty of any kind. Review
[the threat model](https://envgo.dev/reference/threat-model/)
for the behaviours you are responsible for configuring yourself — in particular
rate limiting, which is unlimited unless you set it.
